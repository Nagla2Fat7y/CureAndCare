﻿using Microsoft.EntityFrameworkCore;
using System.Data;

namespace Pharmacy.Models
{
    public class AppDbContext:  DbContext
    {
        public AppDbContext() : base()
        {
        }
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseSqlServer("Server=.;Database=Pharmacy2;Trusted_Connection=True;TrustServerCertificate=True;");

        }
        public DbSet<Pharmacy> Pharmacies { get; set; }
        public DbSet<Med> Medicines { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Manufacturer> Manufacturers { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<PurchaseInvoice> Purchases { get; set; }
        public DbSet<Inventory> Inventories { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<SaleInvoice> SaleInvoices { get; set; }

    }

}
