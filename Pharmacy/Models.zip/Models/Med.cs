﻿using Pharmacy.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Pharmacy.Models
{


    public class Med
    {
        [Key]
        public int M_ID { get; set; }

        [Required]
        [StringLength(100)]
        public string M_Name { get; set; }

        [Required]
        public int M_Quantity { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime Exp_Date { get; set; }

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal M_Price { get; set; }

        public int Low_Stock_Level { get; set; }

        [StringLength(200)]
        public string Expiration_Alert { get; set; }

        [StringLength(500)]
        public string Med_Description { get; set; }
       
        //********************

        [ForeignKey("Category")]
        public int Cat_ID { get; set; }

       
        public virtual Category Category { get; set; }

        [ForeignKey("Manufacturer")]
        public int ManufacturerId { get; set; }
        public virtual Manufacturer Manufacturer { get; set; }

    }
}