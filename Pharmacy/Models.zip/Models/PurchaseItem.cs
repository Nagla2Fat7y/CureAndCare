﻿namespace Pharmacy.Models
{
    public class PurchaseItem
    {
    }
}
