﻿namespace Pharmacy.Models
{
    public class InvoiceItem
    {
    }
}
