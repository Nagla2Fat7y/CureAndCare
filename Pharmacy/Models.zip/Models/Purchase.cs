﻿namespace Pharmacy.Models
{
    public class Purchase
    {
    }
}
