﻿namespace Pharmacy.Models
{
    public class MedicineStock
    {
    }
}
