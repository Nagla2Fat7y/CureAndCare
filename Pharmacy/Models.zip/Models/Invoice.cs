﻿namespace Pharmacy.Models
{
    public class Invoice
    {
    }
}
